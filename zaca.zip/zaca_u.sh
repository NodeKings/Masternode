#!/bin/bash

NONE='\033[00m'
RED='\033[01;31m'
GREEN='\033[01;32m'
YELLOW='\033[01;33m'
ORANGE='\033[0;33m'
PURPLE='\033[01;35m'
CYAN='\033[01;36m'
WHITE='\033[01;37m'
BOLD='\033[1m'
UNDERLINE='\033[4m'
BLU='\e[1;34m'
BU='\033[01;4m'
HIGHL='\e[40;38;5;124m'
MAX=10

ShowWalletInfo() {
    zaca getinfo;
}

ShowWalletSyncStatus() {
   zaca mnsync status
}

MasternodeStatus() {
    zaca masternode status
}

ReindexWallet() {
    echo 'Shuting down wallet daemon...'
    zaca stop > /dev/null 2>&1
    sleep 10
    echo -e "${GREEN}* Done${NONE}";
    cd ~/.rapturecore
    sudo rm governance.dat > /dev/null 2>&1
    sudo rm netfulfilled.dat > /dev/null 2>&1
    sudo rm peers.dat > /dev/null 2>&1
    sudo rm -r blocks > /dev/null 2>&1
    sudo rm mncache.dat > /dev/null 2>&1
    sudo rm -r chainstate > /dev/null 2>&1
    sudo rm fee_estimates.dat > /dev/null 2>&1
    sudo rm mnpayments.dat > /dev/null 2>&1
    sudo rm banlist.dat > /dev/null 2>&1
    cd
    echo 'Starting wallet daemon...'
    zaca -daemon > /dev/null 2>&1
    sleep 5
    echo -e "${GREEN}* Done${NONE}";
    echo 'Waiting for wallet to sync. It will take a while, you can go grab a coffee :)'
    until zaca mnsync status | grep -m 1 '"IsBlockchainSynced": true'; do sleep 1 ; done > /dev/null 2>&1
    echo -e "${GREEN}* Blockchain Synced${NONE}";
    until zaca mnsync status | grep -m 1 '"IsMasternodeListSynced": true'; do sleep 1 ; done > /dev/null 2>&1
    echo -e "${GREEN}* Masternode List Synced${NONE}";
    until zaca mnsync status | grep -m 1 '"IsWinnersListSynced": true'; do sleep 1 ; done > /dev/null 2>&1
    echo -e "${GREEN}* Winners List Synced${NONE}";
    until zaca mnsync status | grep -m 1 '"IsSynced": true'; do sleep 1 ; done > /dev/null 2>&1
    echo -e "${GREEN}* Done reindexing wallet${NONE}";
}

EditWalletConfig() {
    sudo nano ~/.zaca/zaca.conf
}

StartWalletDaemon() {
    zaca -daemon
    sleep 5
}

StopWalletDaemon() {
    zaca stop
    sleep 5
}

echo -e "------------------------------------"
echo -e "| ${HIGHL}Rapture masternode utilities${NONE} |"
echo -e "------------------------------------"
echo
echo -e "${HIGHL}[1]${NONE} Show wallet info"
echo -e "${HIGHL}[2]${NONE} Show wallet sync status"
echo -e "${HIGHL}[3]${NONE} Masternode status"
echo -e "${HIGHL}[4]${NONE} Reindex wallet"
echo -e "${HIGHL}[5]${NONE} Edit wallet config"
echo -e "${HIGHL}[6]${NONE} Start wallet daemon"
echo -e "${HIGHL}[7]${NONE} Stop wallet daemon"
echo

echo -e "${BOLD}What would you like me to do?${NONE}"
read -p "Select option with number: " response
echo

case "$response" in
    ("1") ShowWalletInfo ;;
    ("2") ShowWalletSyncStatus ;;
    ("3") MasternodeStatus ;;
    ("4") ReindexWallet ;;
    ("5") EditWalletConfig ;;
    ("6") StartWalletDaemon ;;
    ("7") StopWalletDaemon ;;
esac